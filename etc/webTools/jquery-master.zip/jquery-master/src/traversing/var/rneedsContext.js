import jQuery from "../../core.js";

import "../../selector.js";

export default jQuery.expr.match.needsContext;
