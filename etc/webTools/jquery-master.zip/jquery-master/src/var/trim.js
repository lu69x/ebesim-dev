export default "".trim;
