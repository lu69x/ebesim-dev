export default Object.getPrototypeOf;
